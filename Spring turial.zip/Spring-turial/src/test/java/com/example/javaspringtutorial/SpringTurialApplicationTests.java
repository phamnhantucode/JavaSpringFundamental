package com.example.javaspringtutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTurialApplicationTests {

	@Test
	void contextLoads() {
	}

}
