package com.example.javaspringtutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTurialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringTurialApplication.class, args);
	}

}
